mysql_pass = 'my_r00tJ'
#mysql_pass = 'G$m07129'