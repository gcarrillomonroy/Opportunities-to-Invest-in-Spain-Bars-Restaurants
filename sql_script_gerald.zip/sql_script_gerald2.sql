USE `B_Project02`;

CREATE TABLE IF NOT EXISTS ConsumerPattern (
	id INT AUTO_INCREMENT,
	Latitude float,
	Longitude float,
	Source text,
	Category text,
	Merchants float,
	Cards float,
	Txs float,
	Avg_amount float,
	Day text,
	Merchants_by_day float,
	Cards_by_day float,
	Txs_by_day float,
	Avg_amount_by_day float,
	Max_amount_by_day float,
	Min_amount_by_day float,
	Std_amount_by_day float,
	Hour time,
	Merchants_by_hour float,
	Cards_by_hour float,
	Txs_by_hour float,
	Avg_amount_by_hour float,
	Max_amount_by_hour float,
	Min_amount_by_hour float,
	Std_amount_hour float,
	PRIMARY KEY (id)
);

select * from ConsumerPattern;
select count(Cards) from ConsumerPattern;