CREATE DATABASE  IF NOT EXISTS `B_Project02`;
USE `B_Project02`;

CREATE TABLE IF NOT EXISTS OriginDistribution (
    id INT AUTO_INCREMENT,
    Latitude float,
	Longitude float,
	Source text,
	Merchants float,
	Cards float,
	Txs float,
	Avg_amount float,
	Category_level text,
	Category text,
	Merchants_by_category float,
	Cards_by_category float,
	Txs_by_category float,
	Avg_amount_by_category float,
    PRIMARY KEY (id)
);

select * from OriginDistribution;
select count(Cards) from OriginDistribution;
